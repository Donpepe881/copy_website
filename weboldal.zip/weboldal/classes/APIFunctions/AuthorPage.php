<?php

class AuthorPage implements IHTTPGET
{

    public function GET(): void
    {
        View::Init("author.html");
    }
}
<?php

class BlogData implements IHTTPGET, IHTTPDELETE
{


    public function DELETE(): void
    {

        if (isset($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT)) {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);

            if ($data = ModelDB::DeleteUser($id)) {

                echo "Success";
            } else {
                echo "A megadott felhasználó nem található!";
            }
        } else {
            echo "Nem megfelelő, vagy hiányos azonosító!";
        }
    }


    public function GET(): void
    {

        View::Init("blogdata.html");

        $data = ModelDB::GetDatas();
        if (count($data) > 0) {

            foreach ($data as $adat) {

                json_encode($adat);
            }
            echo json_encode($data);

        } else {
            View::setResponse(new JSONResponse(array("error" => "Nem található felhasználó!")));
        }
    }
}
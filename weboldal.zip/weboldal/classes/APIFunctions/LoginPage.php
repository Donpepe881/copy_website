<?php

class LoginPage implements IHTTPGET, IHTTPPOST
{

    public function POST(): void
    {
        //session_start();
        View::Init("login.html"); //Itt határozzuk meg a template alapot
        $input = file_get_contents("php://input"); //Ez marad, mert a hívásban továbbra is JSON-ben küldi az infókat a JS
        $json = json_decode($input, true);
        if (is_array($json)) {

            if (isset($json["email"]) && isset($json["pass"]) && trim($json["email"]) != "" && trim($json["pass"]) != "") {
                //$email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $email = htmlspecialchars($json["email"]);
                $pass = hash("sha256", htmlspecialchars($json["pass"]));
                $logins = ModelDB::Login();
                $login = false;

                foreach ($logins as $row) {

                    if (trim($row[1]) == trim($email) && trim($row[2]) == trim($pass)) {
                        $login = true;
                        $_SESSION["name"] = $row[0];
                        $_SESSION["email"] = $row[1];
                        break;
                    }
                    //$_SESSION["name"] = $row[0];
                }

                if ($login) {
                    setcookie('user', $pass);
                    http_response_code(200);
                    echo 'welcome ' . $_SESSION["name"];
                    //$_SESSION["auth"] = true;

                } else {
                    //View::setResponse(new JSONResponse(array("error" => "Beszúrási hiba!")));
                    http_response_code(401);
                    echo "Wrong Email or password";
                }
            } else {
                http_response_code(401);
                echo "Hiányos adatok!";

            }
        } else {
            //View::setResponse(new JSONResponse(array("error" => "Nem értelmezhető bemenet!")));
            echo "Nem értelmezhető bemenet!";
            http_response_code(401);
        }
        exit();
    }

    public function GET(): void //Kell egy GET is így, mert amikor betölt az oldal ezt kell megjeleníteni
    {
        View::Init("login.html");
    }

    /*public static function Run(): Template --> Mivel a View-ba csak belepakoljuk az anyagokat a megfelelő metodikán, ez nem kell.
    {
        
    }*/
}




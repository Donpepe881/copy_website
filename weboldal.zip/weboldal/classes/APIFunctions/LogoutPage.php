<?php

class LogoutPage implements IHTTPGET
{
    public function GET(): void
    {

        if (!isset($_COOKIE['user'])) {
            echo "Sikertelen kijelentkezés!!!";
            exit();
        }
        unset($_SESSION['user']);
        session_destroy();
        setcookie('user', false);
        echo "Sikeresen kijelentkeztél!" . session_start();
        echo "<h4>Ugrás a bejelentkező oldalra: <button style='background-color: #04AA6D;'><a href='http://localhost/Weboldal/index.php?method=LOGINPAGE'>Bejelentkező oldal</a></button></h4>";
        exit();
    }

}
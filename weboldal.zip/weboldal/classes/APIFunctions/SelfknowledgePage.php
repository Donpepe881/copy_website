<?php

class SelfknowledgePage implements IHTTPGET, IHTTPPOST
{
    public function GET(): void
    {
        if (!isset($_COOKIE['user'])) {

            http_response_code(403);
            echo ("<h2 style='text-align: center;'>Az oldal megtekintéséhez előbb jelentkezz be!</h2>");
        } else {

            View::Init("selfknowledge.html");

            $blogDatas = ModelDB::GetDatas();
            $imagesDatas = ModelDB::GetPictures();

            foreach ($blogDatas as $data) {
                foreach ($imagesDatas as $image) {
                    if ($data["id"] == $image["id"]) {
                        View::getBaseTemplate()->AddData("IMAGES", "
                
                        


                    <div class='col'>
                    <div class='card mt-4 col-md6 bg-light'>
                        <div class='card-body' id='{$data['id']}'>
                            <div class='col-md-12 text-center'>
                            <img id='{$image['id']}' class='rounded-circle' src='{$image['imageSource']}' alt='{$image['imageName']}' title='{$image['imageName']}' style='width: 30vw;'>
                            <h5 class='text-center'>{$data['title']}</h5>
                            <h6 class='text-center mb-2 text-muted'>{$data['firstsubtitle']}</h6>
                            <p class='card-text-first'>{$data['firstpara']}</p>
                            <p class='card-text-second'>{$data['secondpara']}</p>
                            <p class='card-text-third'>{$data['thirdpara']}</p>
                            </div>
                            <form method='POST'>
                            <div class='col-md-12 text-center'>
                                <input type='hidden' name='data-id' value='{$data['id']}'>
                                <input type='hidden' name='id-image' value='{$image['id']}'>
                                <button type='submit' name='delete-image' class='btn btn-danger'> Blog bejegyzés törlése</button>
                            </div>
                            </form>
                        </div>
                    </div>
                    </div>
                ");
                    }
                }
            }

            $messages = ModelDB::GetMessages();

            foreach ($messages as $data) {
                View::getBaseTemplate()->AddData("MESSAGES", "
                
                    <tbody>
                        <tr>
                            <td>{$data['id']}</td>
                            <td>{$data['contactName']}</td>
                            <td>{$data['contactEmail']}</td>
                            <td>{$data['contactTextarea']}</td>
                            <td>
                                <form method='POST'>
                                <input type='hidden' name='id-message' value='{$data['id']}'>
                                <button type='submit' name='react-message' class='btn btn-success mr-2'>Reagálás</>
                                <button type='submit' name='delete-message' class='btn btn-danger mr-2'> Üzenet törlése</button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                ");
            }
        }


    }
    public static function DeleteBlogDatas(): void
    {

        if (isset($_POST["data-id"]) && isset($_POST['id-image'])) {

            $dataID = $_POST["data-id"];
            $imageID = $_POST["id-image"];


            if (ModelDB::DeleteBlogData($dataID) && ModelDB::DeleteBlogPictures($imageID)) {

                echo "<div ><div class='alert alert-success alert-dismissible'>
                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                <strong>Sikeres blog bejegyzés törlés!</strong></div></div>";
            } else {
                echo "<div><div class='alert alert-success alert-dismissible'>
                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                <strong>Sikertelen blog bejegyzés törlés!</strong></div></div>";
            }

        }
    }
    public static function DeleteMessage(): void
    {
        if (isset($_POST["id-message"])) {
            $messageID = $_POST["id-message"];

            if (ModelDB::DeleteMessage($messageID)) {

                echo "<div class='container'><div class='alert alert-success alert-dismissible'>
                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                <strong>Sikeres üzenet törlés!</strong></div></div>";
            } else {
                echo "<div class='container'><div class='alert alert-success alert-dismissible'>
                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                <strong>Sikertelen üzenet törlés!</strong></div></div>";
            }
        } else {
            echo "<div class='container'><div class='alert alert-success alert-dismissible'>
                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                <strong>Sikertelen üzenet lekérdezés!</strong></div></div>";
        }
    }

    public function POST(): void
    {



        View::Init("selfknowledge.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);

        $selfemail = $_SESSION["email"];

        if (isset($json["address"]) && isset($json["subject"]) && isset($json["sendtext"])) {


            $address = htmlspecialchars(trim($json["address"]));
            $subject = htmlspecialchars(trim($json["subject"]));
            $sendText = htmlspecialchars(trim($json["sendtext"]));

            if (ModelDB::SendedMessage($selfemail, $address, $subject, $sendText)) {
                http_response_code(200);
                echo "Sikeres válasz küldés!";
            } else {
                http_response_code(401);
                echo "Sikertelen válasz küldés!";
            }
        } else {

            echo "Nem értelmezhető bemenet!";
            http_response_code(401);
        }
        exit();

    }
}
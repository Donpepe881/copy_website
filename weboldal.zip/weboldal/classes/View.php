<?php

//API esetén a feladat ugyan az mint a rendes weboldalaknél - a kimenetet előállítani, kezelni.
abstract class View
{

    private static IViewResponse $response;

    public static function getResponse(): IViewResponse
    {
        return self::$response;
    }

    public static function setResponse(IViewResponse $response): void
    {
        self::$response = $response;
    }

    public static function RenderAndPrint(): void
    {
        header("Content-type: " . self::$response->GetMIMEType());
        print(self::$response->ToStringFormat());
    }

    private static Template $baseTemplate;

    public static function getBaseTemplate(): Template
    {
        return self::$baseTemplate;
    }

    public static function setBaseTemplate(Template $baseTemplate): void
    {
        self::$baseTemplate = $baseTemplate;
    }

    public static function Init(string $templateFilename): void
    {
        self::setBaseTemplate(Template::Load($templateFilename));
    }


    public static function FinalRender(): void
    {
        if (print((self::$baseTemplate->Render()))) {

        } else {
            header("Content-type: " . self::$response->GetMIMEType());
            print(self::$response->ToStringFormat());
        }

    }
}

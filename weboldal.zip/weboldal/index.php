<?php
//phpinfo();

//Weboldal
session_start();
require_once("config.php");
require_once("autoloader.php");
ModelDB::Connect();
Controller::Init();
//Controller::Route();
Controller::DoCall();
//View::RenderAndPrint();

View::FinalRender();

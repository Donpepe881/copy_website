function NewParagraph() {
    var div = document.createElement("div");
    div.setAttribute("class", "form-group");

    var label = document.createElement("label");
    label.innerHTML = "Új bekezdés";

    var textarea = document.createElement("textarea");
    textarea.setAttribute("id", "newPara");
    textarea.setAttribute("class", "form-control");

    div.appendChild(label);
    div.appendChild(textarea);

    let currentDiv = document.getElementById("button");
    let parentDiv = currentDiv.parentNode;



    parentDiv.insertBefore(div, currentDiv);


}
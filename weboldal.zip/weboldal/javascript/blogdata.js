async function GetDatas() {

    fetch("http://localhost/Weboldal/index.php?method=BLOGDATA",
        {
            method: "GET",
            headers:
            {
                "Content-type": "application/json"
            }
        })
        .then(apiresponse => apiresponse.text())
        .then(jsonData => {
            console.log(jsonData);
            var dtable = document.getElementById("blogDatas");
            dtable.innerHTML = "";
            var table = document.createElement("table");
            var header = document.createElement("tr");
            var id = document.createElement("th");
            id.innerHTML = "Azonosító";
            var title = document.createElement("th");
            title.innerHTML = "Blog címe";
            var firstsubtitle = document.createElement("th");
            firstsubtitle.innerHTML = "Első alcím";
            var firstpara = document.createElement("th");
            firstpara.innerHTML = "Első bekezdés";
            var secondpara = document.createElement("th");
            secondpara.innerHTML = "Második bekezdés";
            var newpara = document.createElement("th");
            newpara.innerHTML = "Új bekezdés";
            var del = document.createElement("th");
            del.innerHTML = "Törlés";
            var modified = document.createElement("th");
            modified.innerHTML = "Módosítás";
            header.appendChild(id);
            header.appendChild(title);
            header.appendChild(firstsubtitle);
            header.appendChild(firstpara);
            header.appendChild(secondpara);
            header.appendChild(newpara);
            header.appendChild(del);
            header.appendChild(modified);
            table.appendChild(header);
            for (var i = 0; i < jsonData.length; i++) {

                var row = document.createElement("tr");
                var id = document.createElement("td");
                id.innerHTML = jsonData[i].id;
                var title = document.createElement("td");
                title.innerHTML = jsonData[i].title;
                var firstsubtitle = document.createElement("td");
                firstsubtitle.innerHTML = jsonData[i].firstsubtitle;
                var firstpara = document.createElement("td");
                firstpara.innerHTML = jsonData[i].firstpara;
                var secondpara = document.createElement("td");
                secondpara.innerHTML = jsonData[i].secondpara;
                var newpara = document.createElement("td");
                newpara.innerHTML = jsonData[i].newpara;
                var del = document.createElement("td");
                del.innerHTML = "";
                var modified = document.createElement("td");
                modified.innerHTML = "";

                row.appendChild(id);
                row.appendChild(title);
                row.appendChild(firstsubtitle);
                row.appendChild(firstpara);
                row.appendChild(secondpara);
                row.appendChild(newpara);
                row.appendChild(del);
                row.appendChild(modified);
                table.appendChild(row);

            }
            dtable.appendChild(table);

        });
}


async function AddNewBlogData() {
    var status
    fetch("http://localhost/Weboldal/index.php?method=WELCOMEPAGE",
        {
            'method': "POST",
            headers:
            {
                "Content-type": "application/json",
            },
            body: JSON.stringify({
                "blogname": document.getElementById("blogName").value,
                "firstsubtitle": document.getElementById("firstSubtitle").value,
                "firstparagraph": document.getElementById("firstP").value,
                "secondparagraph": document.getElementById("secondP").value,
                "newparagraph": document.getElementById("newPara").value
            }),
            mode: 'cors',
            credentials: 'include'
        })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {
            console.log(data);
            alert(data)
            GetDatas();
        })
        .catch(err => {
            console.log(err)
        })
}
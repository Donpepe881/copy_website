const postsList = document.querySelector('.posts-list');
const addPostForm = document.querySelector('.add-post-form');
const addUploadData = document.getElementById("uploadDatas")
const titleValue = document.getElementById("blogName");
const firstsubtitle = document.getElementById("firstSubtitle");
const firstparagraph = document.getElementById("firstP");
const secondparagraph = document.getElementById("secondP");
const thirdparagraph = document.getElementById("thirdP");
const btnSubmit = document.getElementById("update");
let output = "";


addPostForm.addEventListener('submit', (e) => {
    e.preventDefault();
    var status
    fetch("http://localhost/Weboldal/index.php?method=WELCOMEPAGE",
        {
            'method': "POST",
            headers:
            {
                "Content-type": "application/json",
            },
            body: JSON.stringify({
                "blogname": titleValue.value,
                "firstsubtitle": firstsubtitle.value,
                "firstparagraph": firstparagraph.value,
                "secondparagraph": secondparagraph.value,
                "thirdparagraph": thirdparagraph.value
            }),
            mode: 'cors',
            credentials: 'include'
        })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {
            console.log(data);
            alert(data)

        })
        .catch(err => {
            console.log(err)
        })
})





const renderPosts = (posts) => {
    posts.forEach(post => {
        output += `
    <div style="width: 45vw;">
    <div class='col'>
        <div class="card mt-4 col-md6 bg-light">
            <div class='col-md-12 text-center'>
            
                <div class="card-body" data-id=${post.id}>
                    <h5 class="card-title">${post.title}</h5>
                    <h6 class="card-subtitle mb-2 text-muted">${post.firstsubtitle}</h6>
                    <p class="card-text-first">${post.firstpara}</p>
                    <p class="card-text-second">${post.secondpara}</p>
                    <p class="card-text-third">${post.thirdpara}</p>
                    <a href="#" class="card-link" id='edit-post'>Edit</a>
                    <a href="#" class="card-link" id='delete-post'>Delete</a>
                </div>
            </div>
        </div>
    </div>
    </div>
    `;
    });
    postsList.innerHTML = output;
}

const url = "http://localhost/Weboldal/index.php?method=BLOGDATA";

// GET - Read the posts
// Method - GET
fetch(url)
    .then(res => res.json())
    .then(data => renderPosts(data))

postsList.addEventListener('click', (e) => {
    e.preventDefault();
    let delButtonIsPressed = e.target.id == 'delete-post';
    let editButtonIsPressed = e.target.id == 'edit-post';

    let id = e.target.parentElement.dataset.id;


    //Delete - Remove the existing post
    // Method: DELETE
    if (delButtonIsPressed) {
        fetch(`${url}&id=` + id, {
            method: 'DELETE',
        })
            .then(res => res.text())
            .then(data => {
                console.log(data)
            })
            .then(() => location.reload())
    }

    if (editButtonIsPressed) {
        const parent = e.target.parentElement;
        let titleContent = parent.querySelector(".card-title").textContent;
        let subtitleContent = parent.querySelector(".card-subtitle").textContent;
        let firstparaContent = parent.querySelector(".card-text-first").textContent;
        let secondparaContent = parent.querySelector(".card-text-second").textContent;
        let thirdparaContent = parent.querySelector(".card-text-third").textContent;

        titleValue.value = titleContent;
        firstsubtitle.value = subtitleContent;
        firstparagraph.value = firstparaContent;
        secondparagraph.value = secondparaContent;
        thirdparagraph.value = thirdparaContent;


        // Update - update the existing post
        // Method: PUT
        btnSubmit.addEventListener("click", (e) => {
            e.preventDefault();
            fetch(`http://localhost/Weboldal/index.php?method=WELCOMEPAGE&id=` + id,
                {
                    method: 'PUT',
                    headers: {
                        "Content-type": "application/json",
                    },
                    body: JSON.stringify({
                        "blogname": titleValue.value,
                        "firstsubtitle": firstsubtitle.value,
                        "firstparagraph": firstparagraph.value,
                        "secondparagraph": secondparagraph.value,
                        "thirdparagraph": thirdparagraph.value
                    })
                })
                .then(res => res.text())
                .then(data => {
                    alert(data)
                })
                .then(() => location.reload())
        })
    }

});

// Create - Insert new post
// Method: POST 
addPostForm.addEventListener('submit', (e) => {
    e.preventDefault();

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            title: titleValue.value,
            firstSubtitle: firstsubtitle.value,
            firstPara: firstparagraph.value,
            secondPara: secondparagraph.value,
            thirdPara: thirdparagraph.value
        })
    })
        .then(res => res.json())
        .then(data => {
            const dataArr = [];
            dataArr.push(data);
            renderPosts(dataArr);
        })


})
function ViewPictures() {
    document.getElementById("images").style = "display: block;";
    document.getElementById("tableData").style = "display: none;";
}

function ViewTable() {
    document.getElementById("tableData").style = "display: block;";
    document.getElementById("images").style = "display: none;";
}



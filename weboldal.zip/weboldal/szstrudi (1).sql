-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: localhost:3307
-- Létrehozás ideje: 2024. Már 14. 19:36
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `szstrudi`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `blogdata`
--

CREATE TABLE `blogdata` (
  `id` int(128) NOT NULL,
  `title` varchar(512) NOT NULL,
  `firstsubtitle` varchar(512) NOT NULL,
  `firstpara` varchar(2048) NOT NULL,
  `secondpara` varchar(2048) NOT NULL,
  `thirdpara` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `blogdata`
--

INSERT INTO `blogdata` (`id`, `title`, `firstsubtitle`, `firstpara`, `secondpara`, `thirdpara`) VALUES
(4, 'És most már biztos jó lesz :D', 'Nagyon jóóóóó', 'Muhahahhahah', 'Muhahahaah', 'Muhahahhaha');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `blogimages`
--

CREATE TABLE `blogimages` (
  `id` int(11) NOT NULL,
  `imageSource` varchar(256) NOT NULL,
  `imageName` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `blogimages`
--

INSERT INTO `blogimages` (`id`, `imageSource`, `imageName`) VALUES
(4, 'kepek/malta-455168.jpg.png', 'malta-455168.jpg.png'),
(5, 'kepek/malta-455168.jpg.png', 'malta-455168.jpg.png'),
(6, 'kepek/malta-455168.jpg.png', 'malta-455168.jpg.png'),
(7, 'kepek/malta-455168.jpg.png', 'malta-455168.jpg.png'),
(8, 'kepek/urban-prague-wallpaper-95a094a3a798911c5c784bd04e58e4e3.jpg.png', 'urban-prague-wallpaper-95a094a3a798911c5c784bd04e58e4e3.jpg.png'),
(9, 'kepek/malta-455168.jpg.png', 'malta-455168.jpg.png');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contact`
--

CREATE TABLE `contact` (
  `id` int(20) NOT NULL,
  `contactName` varchar(128) NOT NULL,
  `contactEmail` varchar(128) NOT NULL,
  `contactTextarea` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contact`
--

INSERT INTO `contact` (`id`, `contactName`, `contactEmail`, `contactTextarea`) VALUES
(10, 'Pedro', 'joope45@gmail.com', 'sdfsdfdf');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sendedmessage`
--

CREATE TABLE `sendedmessage` (
  `id` int(128) NOT NULL,
  `selfemail` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `subject` varchar(512) NOT NULL,
  `sendtext` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `sendedmessage`
--

INSERT INTO `sendedmessage` (`id`, `selfemail`, `address`, `subject`, `sendtext`) VALUES
(1, 'joope45@gmail.com', 'joope45@gmail.com', 'Na most már biztos jó lesz :D', 'Muhahahahahah'),
(2, 'joope45@gmail.com', 'joope45@gmail.com', 'Na és bízzunk benne, hogy most is :D', 'Muhahahahahah'),
(3, 'joope45@gmail.com', 'joope45@gmail.com', 'Na majd most :D', 'Muhahahahaha');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `name` varchar(512) NOT NULL,
  `email` varchar(512) NOT NULL,
  `pass` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`name`, `email`, `pass`) VALUES
('Joó Péter', 'joope45@gmail.com', '4760e26131ce7f07384adda2861ab5b56407854b35bfaca0ac63f793085c1264'),
('Eszes Gertrúd', 'gertrud.eszes@gmail.com', '4760e26131ce7f07384adda2861ab5b56407854b35bfaca0ac63f793085c1264');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `blogdata`
--
ALTER TABLE `blogdata`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `blogimages`
--
ALTER TABLE `blogimages`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `sendedmessage`
--
ALTER TABLE `sendedmessage`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `blogdata`
--
ALTER TABLE `blogdata`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `blogimages`
--
ALTER TABLE `blogimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `sendedmessage`
--
ALTER TABLE `sendedmessage`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
